package com.nway.cache;

public class CacheEntry<K,V> {
    public K key;
    public V value;
}

